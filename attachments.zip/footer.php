<style>
.center {
	text-align: center;
}
.center {
	text-align: center;
}
-->
</style>



<link href="facebook div styles.css" rel="stylesheet" type="text/css" />


<div class="fb2">
  <table width="760" border="0">
  <tr>
    <th width="234" scope="col"><a href="http://apps.facebook.com/spatchaker/about_us.php" target="_top">About Us</a></th>
    <th width="278" scope="col"><a href="http://apps.facebook.com/spatchaker/contact_us.php" target="_top">Contact Us</a></th>
    <th width="234" scope="col"><a href="http://apps.facebook.com/spatchaker/help.php" target="_top">Help</a></th>
  </tr>
</table>
</div>
