<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Match Center</title>
<link href="facebook div styles.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="fb" id='fb'>

<?php
include_once("header.php");
?>
<br />
<br />
<p align="center">
  <h9 class="fb">Welcome to the MatchCenter</h9>
</p>
<br />

  <div class="fby">
    <H3>Recommended Matches
 </H3>
 <br />
    <div class='fb6'>
        
          <div class='fb6a'>
      <img align="absmiddle" src="https://graph.facebook.com/picture/" width="87" height="111" /></div>
        
            <div class='fb6b'> <span class='fb6cname'>Name:</span></p>
            <br /><br />
            </div>
          
      <div class='fb6c'>
            <ul>
            <a href="#">
            <li>Sport -- </li></a>
            
            <a href="#">
            <li>Time --</li></a>
            
            <a href="http://www.facebook.com/addfriend.php?id=725566721">
            <li>Date -- </li></a>
            
            <a href="http://www.new.facebook.com/inbox/?compose&amp;id=725566721">
            <li>Respond -- Yes / No</li>
            <li>Message The Person</li>
            </a>
            </ul>
</div>

      <p>&nbsp;</p>
      <p>&nbsp;</p>
<p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    </div>
    <br/>
    <div class='fb6'>
        
          <div class='fb6a'>
      <img align="absmiddle" src="https://graph.facebook.com/picture/" width="87" height="111" /></div>
        
            <div class='fb6b'> <span class='fb6cname'>Name:</span></p>
            <br /><br />
            </div>
          
      <div class='fb6c'>
            <ul>
            <a href="#">
            <li>Sport -- </li></a>
            
            <a href="#">
            <li>Time --</li></a>
            
            <a href="http://www.facebook.com/addfriend.php?id=725566721">
            <li>Date -- </li></a>
            
            <a href="http://www.new.facebook.com/inbox/?compose&amp;id=725566721">
            <li>Respond -- Yes / No</li>
            <li>Message The Person</li>
            </a>
            </ul>
</div>

      <p>&nbsp;</p>
      <p>&nbsp;</p>
<p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    </div>
  </div>





<div class="fbx">

<h3>Leave Feed Back on you previous matches</h3>
<br/>
<br/>

  
</div>


<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<br /><br /><br />
<br /><br /><br />
<br /><br /><br />
<br /><br /><br />


<?php include_once("footer.php"); ?>

</div>
</body>
</html>