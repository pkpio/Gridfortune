<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Header</title>

<link href="facebook div styles.css" rel="stylesheet" type="text/css" />

</head>

<body>

<div class="fb" id='fb'>


<div class="fb1"> <h1>The Match Maker</h1></div>
<br />

<div class="fb2">
  <table width="582" border="0">
    <tr>
      <td width="89" height="23"><a href="#">Home</a></td>
      <td width="121"><a href="http://apps.facebook.com/spatchaker/profile.php" target="_top">Profile</a></td>
      <td width="122"><a href="about.html">About Us</a></td>
      <td width="118"><a href="blog.html">Blog</a></td>
      <td width="110"><a href="contact.html">Contact Us</a></td>
    </tr>
  </table>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><br />
  <br />
  <br /><br />
</p>
</div>

</body>
</html>