<?php

$id = $_COOKIE['userid'];

// Connect to database

include_once "connect_to_mysql.php";
	 
	mysql_select_db("spatchaker", $con);
	 
	$query = "SELECT * FROM my_members WHERE id = '$id' ";
	$result = mysql_query($query);
	$userdata = mysql_fetch_array($result);


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">

.edit{
	font-size:9px;
	text-decoration:none;
}

.centering {
	text-align: center;
	
}
</style>


<script type="text/javascript">
function showHint(str)
{
var xmlhttp;
if (str.length==0)
  { 
  document.getElementById("txtHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","gethint.php?q="+str,true);
xmlhttp.send();
}
</script>

</head>

<body>

<?php if (empty($userdata["ldap_id"])): ?>
// Redirect the user to edit_profile_new.php as he is going to be a new user in that case.

echo("<script> top.location.href='http://apps.facebook.com/miki-mona/profile_edit_new.php'</script>");

<?php else: ?>



<?php 
//The user has signed up before so now we will show him his profile information we have in our database
     
//Loading data into session variables
	 
	 $id = $userdata["id"];
	 $name = $userdata["name"];
	 $department = $userdata["department"];
	 $hostel = $userdata["hostel"];
	 $about_me = $userdata["about_me"];
	 $ldap_id = $userdata["ldap_id"];
	 $email_active = $userdata["email_active"];
	 $tennis = $userdata["tennis"];
	 $baddy = $userdata["baddy"];
	 $squash = $userdata["squash"];
	 $table_tennis = $userdata["table_tennis"];
	 $first_time = $userdata["first_time"];
	
?>
<?php include_once "header.php"; ?>

<h1 class="centering">Hello <?php echo $_COOKIE['username']; ?> !</h1><br />
<form action="" class="centering"> 
Search People: <input type="text" id="txt1" onkeyup="showHint(this.value)" />
</form>
<p>Suggestions: <span id="txtHint"></span></p> 


<h3 class="centering">Profile info<sup><a href="http://apps.facebook.com/miki-mona/edit_profile.php" class="edit" target="_top">&nbsp;&nbsp;&nbsp;Edit</a></sup></h3>
<p><b>Name:</b><?php echo $name; ?></p><br />
<p><b>Department:</b><?php echo $department; ?></p><br />
<p><b>Hostel:</b><?php echo $hostel; ?></p><br />
<p><b>About Me:</b><?php echo $about_me; ?></p><br />
<p><b>LDAP Id:</b><?php echo $ldap_id; ?></p><br /><br />
<h3 class="centering">Sports Info<sup><a href="http://apps.facebook.com/miki-mona/edit_profile.php" class="edit" target="_top">&nbsp;&nbsp;&nbsp;Edit</a></sup></h3>
<?php if($tennis=='1'){echo "<p><ul><li>Tennis</li></ul></p>"; } else { } ?>
<?php if($baddy=='1'){echo "<p><ul><li>Baddy</ul></li></p>"; } else { } ?>
<?php if($table_tennis=='1'){echo "<p><ul><li>Table tennis</li></ul></p>"; } else { } ?>
<?php if($squash=='1'){echo "<p><ul><li>Squash</li></ul></p>"; } else { } ?>



<?php endif ?>

<?php include_once "footer.php"; ?>




</body>
</html>