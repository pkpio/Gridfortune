<?php

echo $_REQUEST['variable'];

?>