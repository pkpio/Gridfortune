<html>
<body>

Welcome <?php echo $_GET["fname"]; ?>!<br />
You are <?php echo $_GET["age"]; ?> years old.
You are from <?php echo $_GET["dept"]; ?> ?

</body>
</html> 