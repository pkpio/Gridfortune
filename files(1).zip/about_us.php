<html>
<body>

<?php include_once "header.php"; ?>


<table width="760" border="0">
  <tr>
    <td width="754"> <p>This Facebook app is th product of a languid summer and the WnCC club.</p></td>
  </tr>
</table>
<p>The Coders -<br />
</p>
<table width="760" border="0">
  <tr>
    <td width="754"><a href="www.facebook.com/sampathsatti" target="_top">Sampath Satti</a></td>
  </tr>
  <tr>
    <td><a href="www.facebook.com/sampathsatti" target="_top">Sabaressh Nikhil</a></td>
  </tr>
  <tr>
    <td><a href="www.facebook.com/sampathsatti" target="_top">Praveen Pendyala</a></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="760" border="0">
  <tr>
    <td><p><br />
      The motivation for this app arises from my inability to find partners to play a sport. Simply because I did not know them. The Immense popularity and the huge amout of time we spend on Facebook also made this effort an FB app rather than a full fledged website.</p>
      <p>We plan to add many features and convert this into a one stop portal for sports@IITB.</p>
      <p>Last but not the least, thank you, Saif, Hasan ( yeah different guys ) and the WnCC club.</p>
      <p>Long live Facebook.<br />
    </p></td>
  </tr>
</table>
<p><br />
</p>
<?php include_once "footer.php"; ?>

</body>
</html>
