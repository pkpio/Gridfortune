
<link href="facebook div styles.css" rel="stylesheet" type="text/css" />

<div class="fb1"> <h1>The Match Maker</h1></div>
<br />

<div class="fb2">
  <table width="760" border="0" align="center">
    <tr>
      <td width="137" height="23"><a href="http://localhost/app">Home</a></td>
      <td width="147"><a href="http://apps.facebook.com/spatchaker/profile.php" target="_top">Profile</a></td>
      <td width="158"><a href="matchcenter.php">MatchCenter</a></td>
      <td width="120"><a href="blog.html">Blog</a></td>
      <td width="176"><a href="contact.html">Contact Us</a></td>
    </tr>
  </table>
</div>
