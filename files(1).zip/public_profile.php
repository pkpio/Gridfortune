<?php include_once "header.php"; ?>
<?php
// $name = $_GET['name'];
$name = "Sampath Satti";
?>

<?php
// Connect to database
include_once "connect_to_mysql.php";
	 
	mysql_select_db("spatchaker", $con);
	 
	$query = "SELECT * FROM my_members WHERE name = '$name' ";
	$result = mysql_query($query);
	$userdata = mysql_fetch_array($result);
	
	//Loading data into session variables
	 
	 $id = $userdata["id"];
	 $name = $userdata["name"];
	 $department = $userdata["department"];
	 $hostel = $userdata["hostel"];
	 $about_me = $userdata["about_me"];
	 $tennis = $userdata["tennis"];
	 $baddy = $userdata["baddy"];
	 $squash = $userdata["squash"];
	 $table_tennis = $userdata["table_tennis"];


?>


<html>
<head>
<head>
<style>
.centering{
	text-align:center;
}
</style>
</head>
<body>
<br/><h2 class="centering">Public Profile of <?php echo $name ?></h2><br/><br/>
<h3 class="centering">Profile info</h3>
<p><b>Name:</b><?php echo $name; ?></p><br />
<p><b>Department:</b><?php echo $department; ?></p><br />
<p><b>Hostel:</b><?php echo $hostel; ?></p><br />
<p><b>About <?php echo $name ?>:</b><?php echo $about_me; ?></p><br /><br/><br/>
<h3 class="centering">Sports Info</h3>
<?php if($tennis=='1'){echo "<p><ul><li>Tennis</li></ul></p>"; } else { } ?>
<?php if($baddy=='1'){echo "<p><ul><li>Baddy</ul></li></p>"; } else { } ?>
<?php if($table_tennis=='1'){echo "<p><ul><li>Table tennis</li></ul></p>"; } else { } ?>
<?php if($squash=='1'){echo "<p><ul><li>Squash</li></ul></p>"; } else { } ?><br/><br/>


</body>
</html>
<?php include_once "footer.php"; ?>