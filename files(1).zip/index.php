<?php
/**
* Copyright 2011 Facebook, Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may
* not use this file except in compliance with the License. You may obtain
* a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations
* under the License.
*/

require 'facebook.php';

// Create our Application instance (replace this with your appId and secret).
$facebook = new Facebook(array(
  'appId' => '181323078583708',
  'secret' => '36eb808bdff38a8a4c783952f2537622',
));

  //set application urls here
    $fbconfig['baseUrl']    =   "http://localhost/app/"; //http://thinkdiff.net/demo/newfbconnect1/iframe;
    $fbconfig['appBaseUrl'] =   "http://apps.facebook.com/spatchaker/"; //http://apps.facebook.com/thinkdiffdemo;

// Get User ID
$user = $facebook->getUser();

// We may or may not have this data based on whether the user is logged in.
//
// If we have a $user id here, it means we know the user is logged into
// Facebook, but we don't know if the access token is valid. An access
// token is invalid if the user logged out of Facebook.

if ($user) {
  try {
    // Proceed knowing you have a logged in user who's authenticated.
    $user_profile = $facebook->api('/me');
	

 setcookie("user", $user_profile['id'], time()+36000);

	$_COOKIE["fb_id"] = $user_profile['id'];

	
	$_SESSION['user'] = $user_profile;
	
  } catch (FacebookApiException $e) {
    error_log($e);
    $user = null;
  }
}

// Login or logout url will be needed depending on current user state.
if ($user) {
  $logoutUrl = $facebook->getLogoutUrl();
  
  
  
  
 
} else {
  $loginUrl = $facebook->getLoginUrl(
            array(
            'canvas'    => 1,
            'fbconnect' => 0,
            'req_perms' => 'email,publish_stream,status_update,user_birthday,user_location,user_work_history'
            )
    );
}


$id = $user_profile['id'];

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("spatchaker", $con);

$query = "SELECT * FROM my_members WHERE id = '$id' ";
$result = mysql_query($query);

if(!$result){

mysql_query("INSERT INTO my_members (id, name, year, department, hostel, about_me, tennis)
VALUES ($fb_id, 'Sampath Satti', '1', 'ee', '6', 'I play almost all racquet sports', '1')");

}


// $result_final = mysql_fetch_array($result);

?>
<html>
<body>

<?php print_r($user_profile); ?>



<?php include_once "header.php"; ?>

<?php include_once "home.php"; ?>

<?php include_once "footer.php"; ?>

</body>
</html>




  