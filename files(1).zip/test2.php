<html>
<head>
</head>
<body>

<a href="test3.php?variable=3" >Click this</a>

</body>
</html>