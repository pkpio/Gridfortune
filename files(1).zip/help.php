<html>
<body>

<?php include_once "header.php"; ?>


<br />
<table width="400" border="0">
  <tr>
    <th scope="col">The help page, incl. FAQ's will be put up later. <br />
Thank you for your patience </th>
  </tr>
</table>
<br />


<?php include_once "footer.php"; ?>

</body>
</html>

